package pers.owen.whitescreen

import android.app.Application

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Thread.sleep(2000)
    }
}