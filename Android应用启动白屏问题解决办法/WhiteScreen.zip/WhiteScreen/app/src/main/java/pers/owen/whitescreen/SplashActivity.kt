package pers.owen.whitescreen

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // 注意这里将主题设置回应用的原有主题
        setTheme(R.style.Theme_WhiteScreen)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        thread {
            Thread.sleep(1000)
            runOnUiThread(Runnable {startActivity(Intent(this, MainActivity::class.java))})
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
}