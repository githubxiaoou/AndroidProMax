package pers.owen.whitescreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlin.concurrent.thread

class SplashActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_WhiteScreen)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash2)
        thread {
            Thread.sleep(1000)
            runOnUiThread(Runnable {startActivity(Intent(this, MainActivity::class.java))})
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
}