package pers.owen.my_mvvm.vm;

import android.util.Log;
import android.view.View;

import pers.owen.my_mvvm.databinding.ActivityMainBinding;
import pers.owen.my_mvvm.model.UserInfo;

public class LoginViewModel {
    public UserInfo userInfo;

    public LoginViewModel(ActivityMainBinding binding) {
        userInfo = new UserInfo();
        // 将ViewModel和View进行绑定，通过DataBinding工具。
        binding.setLoginViewModel(this);
    }

    public View.OnClickListener loginClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // 尝试1：view --> model单向绑定测试，改变EditText的值，查看bean中的对应属性值是否发生变化。
//            Log.e("owen >>> ", userInfo.name.get() + "--" + userInfo.pwd.get());

            // 尝试2：model --> view单向绑定测试，Model层属性的变更，也会改变View层的显示
//            userInfo.name.set("Owen");
//            userInfo.pwd.set("0410");

            // 尝试3：模拟网络请求
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if ("Owen".equals(userInfo.name.get()) && "123".equals(userInfo.pwd.get())) {
                        Log.e("Owen >>> ", "登录成功!");
                    } else {
                        Log.e("Owen >>> ", "登录失败!");
                    }
                }
            }).start();
        }
    };
}
