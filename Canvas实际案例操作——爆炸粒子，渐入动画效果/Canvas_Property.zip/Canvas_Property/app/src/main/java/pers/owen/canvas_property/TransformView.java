package pers.owen.canvas_property;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.View;

/**
 * 变换操作
 */
public class TransformView extends View {
    private Paint mPaint;

    public TransformView(Context context) {
        this(context, null);
    }

    public TransformView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TransformView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mPaint = new Paint();
        mPaint.setColor(Color.RED);
        mPaint.setStrokeWidth(8);
        mPaint.setStyle(Paint.Style.STROKE);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onDraw(Canvas canvas) {
        //1、平移操作
//        canvas.drawRect(0, 0, 400, 400, mPaint);
//        canvas.translate(50,50);
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(0, 0, 400, 400, mPaint);
//        canvas.drawLine(0,0,600,600,mPaint);

        //2、缩放操作
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.scale(0.5f, 0.5f);
//        canvas.scale(0.5f, 0.5f, 300, 300);
//
//        // 先translate(px, py),再scale(sx, sy),再反向translate
//        canvas.translate(300, 300);
//        canvas.scale(0.5f, 0.5f);
//        canvas.translate(-300, -300);
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.drawLine(0,0,600,600,mPaint);

        //3、旋转操作
//        canvas.drawRect(300, 300, 600, 600, mPaint);
////        canvas.rotate(45);
//        canvas.rotate(30,450,450);//px,py表示旋转中心
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(300, 300, 600, 600, mPaint);

        // 4、倾斜操作
//        canvas.drawRect(0, 0, 300, 300, mPaint);
////        canvas.skew(1,0);//在X方向倾斜45度,Y轴逆时针旋转45
//        canvas.skew(0, 1);//在Y方向倾斜45度,X轴顺时针旋转45
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(0, 0, 300, 300, mPaint);

//        //5、切割操作
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.clipRect(300, 300, 600, 600);//画布被裁剪
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(350, 350, 650, 650, mPaint);//超出画布区域的无法绘制，画布内的可以正常绘制
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.clipOutRect(300, 300, 600, 600);//画布被裁剪
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(350, 350, 650, 650, mPaint);//超出画布区域的无法绘制，画布内的可以正常绘制

        //6、矩阵
        canvas.drawRect(300, 300, 600, 600, mPaint);
        Matrix matrix = new Matrix();
//        matrix.setTranslate(50, 50);
//        matrix.setRotate(45, 450, 450);
        matrix.setScale(0.5f, 0.5f);
        canvas.setMatrix(matrix);
        mPaint.setColor(Color.BLUE);
        canvas.drawRect(300, 300, 600, 600, mPaint);

        //7、保存/恢复
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        Log.e("TAG", "count :" + canvas.getSaveCount());
//        int state = canvas.save();//保存
//        Log.e("TAG", "count :" + canvas.getSaveCount());
//        canvas.translate(50, 50);
//        canvas.scale(0.5f, 0.5f);
        //...
//        canvas.scale(2f, 2f);
//        canvas.translate(-50, -50);
//        mPaint.setColor(Color.GREEN);
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.save();//保存
//        Log.e("TAG", "count :" + canvas.getSaveCount());
//        canvas.translate(50, 50);
//        mPaint.setColor(Color.YELLOW);
//        canvas.drawRect(400, 400, 700, 700, mPaint);
////        canvas.restore();//恢复
////        canvas.restore();//恢复
//        canvas.restoreToCount(state);
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        canvas.drawRect(300, 300, 600, 600, mPaint);
//        int saveLayer = canvas.saveLayer(0, 0, 700, 700, mPaint);
//        canvas.translate(100, 100);
//        canvas.drawRect(0, 0, 700, 700, mPaint);//由于平移操作，导致绘制的矩形超出了图层的大小，所以绘制不完全
////        canvas.restore();
//        canvas.restoreToCount(saveLayer);
//        mPaint.setColor(Color.BLUE);
//        canvas.drawRect(0, 0, 100, 100, mPaint);

    }
}
