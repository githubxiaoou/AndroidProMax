package pers.owen.databinding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import pers.owen.databinding.databinding.ActivityMainBinding;
import pers.owen.databinding.model.UserInfo;

public class MainActivity extends AppCompatActivity {
    private UserInfo userInfo = new UserInfo();
    private final static String TAG = "TAG >>>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        // 尝试1：单向绑定第一种方式：<Model -- View>
//        userInfo.setName("Owen");
//        userInfo.setPwd("123");
//        binding.setUser(userInfo);
//
//        Log.e(TAG, userInfo.getName() + " / " + userInfo.getPwd());
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                userInfo.setName("Sara");
//                userInfo.setPwd("222");
//                Log.e(TAG, userInfo.getName() + " / " + userInfo.getPwd());
//            }
//        }, 2000);

        // 尝试2：单向绑定第二种方式：<Model -- View>
//        userInfo.name.set("Owen");
//        userInfo.pwd.set("123");
//        binding.setUser(userInfo);
//        Log.e(TAG, userInfo.name.get() + " / " + userInfo.pwd.get());
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                userInfo.name.set("Sara");
//                userInfo.pwd.set("222");
//                Log.e(TAG, userInfo.name.get() + " / " + userInfo.pwd.get());
//            }
//        }, 2000);

        // 尝试3：双向绑定(Model --- View     View  --- Model)
        userInfo.name.set("Owen");
        userInfo.pwd.set("123");
        binding.setUser(userInfo);

        Log.e(TAG, userInfo.name.get() + " / " + userInfo.pwd.get());

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e(TAG, userInfo.name.get() + " / " + userInfo.pwd.get());
            }
        }, 6000);
    }
}
