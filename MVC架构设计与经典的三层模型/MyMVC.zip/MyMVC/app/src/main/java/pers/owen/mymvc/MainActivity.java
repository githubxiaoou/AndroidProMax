package pers.owen.mymvc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import pers.owen.mymvc.bean.ImageBean;

public class MainActivity extends AppCompatActivity implements Callback {
    private ImageView imageView;
    private final static String PATH = "https://dss1.baidu.com/70cFfyinKgQFm2e88IuM_a/forum/pic/item/9f2f070828381f300704a682a7014c086e06f0f8.jpg";

    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case ImageDownloader.SUCCESS:// 成功
                    imageView.setImageBitmap(((Bitmap) msg.obj));
                    break;
                case ImageDownloader.ERROR:// 失败
                    Toast.makeText(MainActivity.this, "下载失败", Toast.LENGTH_SHORT).show();
                    break;
            }
            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.iv_image);

        // 内存泄漏
        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(50000);
            }
        }).start();
    }

    // 点击事件
    public void getImage(View view) {
        ImageBean imageBean = new ImageBean();
        imageBean.setRequestPath(PATH);
        new ImageDownloader().down(this, imageBean);
    }

    @Override
    public void callback(int resultCode, ImageBean imageBean) {
        Message message = mHandler.obtainMessage(resultCode);
        message.obj = imageBean.getBitmap();
        mHandler.sendMessageDelayed(message, 500);
    }
}
